# Ejecución para el algoritmo A

from City import City


class A:
  def __init__(self):
    self.lower = City

  