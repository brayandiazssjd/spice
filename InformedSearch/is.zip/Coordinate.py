class Coordinate:
  def __init__(self, degrees, minutes, seconds):
    self.degrees = degrees
    self.minutes = minutes
    self.seconds = seconds